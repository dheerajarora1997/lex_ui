export const USER_TYPE_OPTIONS = [
  {
    value: "LAWYER",
    label: "Lawyer",
  },
  {
    value: "JUDGE",
    label: "Judge",
  },
  {
    value: "PROFESSOR",
    label: "Professor",
  },
  {
    value: "LAW_FIRM",
    label: "Law Firm",
  },
  {
    value: "CORPORATE",
    label: "Corporate",
  },
  {
    value: "STUDENT",
    label: "Student",
  },
  {
    value: "Other",
    label: "Other",
  },
];
