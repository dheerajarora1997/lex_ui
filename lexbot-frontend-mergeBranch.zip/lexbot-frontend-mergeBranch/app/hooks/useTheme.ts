function useTheme() {
  return null;
}

export default useTheme;
