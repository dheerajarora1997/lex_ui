export const ONBOARDING_CARD_DETAILS_LIST = [
  {
    title: "Boolean Search",
    subHeading: "Here's how you can utilize lex to perform various searches.",
    lineOne: `Give me cases where with contract end breach`,
    title1: "Section Search",
    lineOne1: `Give me searches related to section3(1)`,
    title2: "Search by Date",
    lineOne2: `Give me contract breach cases from 2003`,
    title3: "Search by Case",
    lineOne3: `Give me detailed case study on Keshvanand Bharti case`,
    desc: "... Not just that—you can search with limitless possibilities, handling all your research effortlessly!",
  },
  {
    largeTitle: "Ready to Start You First LEX Research!!",
    largeText: `As a reminder, Lex is still in Beta, and your feedback is invaluable in helping us improve.`,
    desc: `Look for the "Feedback" button after every message – we'd love to hear your thoughts!
Thanks for joining the Lex community!`,
  },
];
