import styles from "../styles/onboarding.module.scss";

function CardHeader() {
  return (
    <div className={styles.card_header}>
      <div className={styles.details_container}>
        <span className={styles.title}>Searching The Lex Way</span>
      </div>
    </div>
  );
}

export default CardHeader;
{
}
