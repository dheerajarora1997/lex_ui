export interface APIErrorData {
  detail?: string | undefined | null;
  error?: [string];
}
