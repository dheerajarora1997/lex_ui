export const APP_ERROR_MESSAGE = "Something went wrong!";
