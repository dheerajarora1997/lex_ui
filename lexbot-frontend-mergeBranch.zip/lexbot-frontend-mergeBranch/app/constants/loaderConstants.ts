export const loaderConstants = [
  `Discourage litigation. Persuade your neighbors to compromise whenever you can. As a peacemaker the lawyer has superior opportunity of being a good man. There will still be business enough.`,

  `Never hate your enemies. It affects your judgment.`,

  `I chose to go to law school because I thought that someday, somehow I’d make a differenceDarden.`,

  `A lawyer without books would be like a workman without tools.`,

  `Success usually comes to those who are too busy to be looking for it.`,

  `Necessity knows no law; I know some attorneys of the same,.`,
  `As a lawyer, I can assure you that a lot of document drafting is repetitive, involving cutting and pasting from templates. But the best lawyers bring a unique perspective to the process and anticipate clients’ problems.`,

  `The good lawyer is not the man who has an eye to every side and angle of contingency, and qualifies all his qualifications, but who throws himself on your part so heartily, that he can get you out of a scrapeRalph Waldo Emerson.`,
];
