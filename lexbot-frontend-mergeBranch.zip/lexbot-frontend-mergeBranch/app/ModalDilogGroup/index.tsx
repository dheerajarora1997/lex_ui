"use client";
import { useEffect, useState } from "react";
import "./modalOverwrite.scss";
import { useAppSelector } from "../store/store";
import {
  setModalData,
  setModalDetailId,
} from "../store/slices/frontendElements";
import { useDispatch } from "react-redux";
import {
  useFeedbackApiMutation,
  useGetJudmentFileQuery,
  useViewConversationQuery,
} from "../apiService/services/conversationApi";
import {
  showErrorToast,
  showInfoToast,
  showSuccessToast,
} from "../hooks/useNotify";
import Loader from "../components/common/Loader";

export interface JsonData {
  [key: string]: string | number | null | JsonData | string[] | JsonData[];
}
interface FetchBaseQueryError {
  data?: {
    non_field_errors?: string[];
    message?: string;
  };
}

export default function ModalDilogGroup() {
  const dispatch = useDispatch();
  const modalData = useAppSelector(
    (state) => state?.frontendElements?.modalData
  );
  const modalDetailId = useAppSelector(
    (state) => state?.frontendElements?.modalDetailId
  );

  const [fileId, setFileId] = useState<string | undefined>(undefined);
  const [pdfLink, setPdfLink] = useState<string>("");

  const EnableRightElement = () => {
    const modalRightElement = document.querySelector(".modal-right-element");
    const modalDialog = document.querySelector(
      ".modal.custom-slide-modal .modal-dialog"
    );
    modalRightElement?.classList?.remove("d-none");
    modalDialog?.classList?.add("modal-fullscreen");
  };
  const DisableRightElement = () => {
    const modalRightElement = document.querySelector(".modal-right-element");
    const modalDialog = document.querySelector(
      ".modal.custom-slide-modal .modal-dialog"
    );
    modalRightElement?.classList?.add("d-none");
    modalDialog?.classList?.remove("modal-fullscreen");
  };
  const resetAllData = () => {
    DisableRightElement();
    setFileId(undefined);
    setPdfLink("");
    dispatch(setModalData(null));
    dispatch(setModalDetailId(null));
  };

  const { data: conversationDataView, refetch: viewConversation } =
    useViewConversationQuery(
      { id: modalDetailId ? modalDetailId?.toString() : "" },
      { skip: !modalDetailId }
    );

  useEffect(() => {
    if (modalDetailId) {
      viewConversation();
    }
  }, [modalDetailId]);

  useEffect(() => {
    if (conversationDataView && modalDetailId) {
      dispatch(setModalData(conversationDataView?.search_results));
    }
  }, [conversationDataView, modalDetailId]);

  const {
    data,
    refetch: getJudmentFile,
    status,
    error,
  } = useGetJudmentFileQuery({ id: fileId ? fileId : "" }, { skip: !fileId });
  useEffect(() => {
    if (fileId) {
      getJudmentFile();
    }
  }, [fileId]);

  useEffect(() => {
    if (data) {
      setPdfLink(data?.presigned_url);
    }
  }, [data]);
  useEffect(() => {
    if (status == "rejected") {
      showInfoToast("This feature is only available for premium users.");
      setTimeout(() => {
        setFileId(undefined);
        setPdfLink("");
        DisableRightElement();
      }, 1500);
      return;
    }
  }, [error]);

  const [suggestionMsg, setSuggestionMsg] = useState<string>("");
  const [feedbackSuggestion, setFeedbackSuggestion] = useState<string[]>([]);

  const handleCheckboxChange = (option: string) => {
    setFeedbackSuggestion((prev) =>
      prev.includes(option)
        ? prev.filter((item) => item !== option)
        : [...prev, option]
    );
  };

  const clearPayload = () => {
    setSuggestionMsg("");
    setFeedbackSuggestion([]);
  };
  const feedbackConvoId = useAppSelector(
    (state) => state?.frontendElements?.feedbackConvoId
  );
  const feedbackConvoLike = useAppSelector(
    (state) => state?.frontendElements?.feedbackConvoLike
  );

  const checkBoxOptions = [
    "Inaccurate",
    "Out of date",
    "Offensive",
    "Irrelevant",
  ];

  const payload = {
    conversation: feedbackConvoId,
    liked: feedbackConvoLike,
    rating: 5,
    feedback_text: suggestionMsg,
    feedback_suggestions: feedbackSuggestion,
  };

  const [feedbackApi, { isLoading, error: feedbackError, data: feedBackData }] =
    useFeedbackApiMutation({});

  const submitFeedback = () => {
    feedbackApi(payload);
  };
  useEffect(() => {
    if (feedbackError) {
      const errorMessage =
        (feedbackError as FetchBaseQueryError)?.data?.message ||
        "Feedback not submitted. Please try again.";
      showErrorToast(errorMessage);
    }
  }, [feedbackError]);
  useEffect(() => {
    if (feedBackData) {
      showSuccessToast("Feedback submitted successfully.");
      clearPayload();
    }
  }, [feedBackData]);

  useEffect(() => {
    console.log(pdfLink, "pdfLink");
    if (pdfLink) {
      EnableRightElement();
    } else {
      DisableRightElement();
    }
  }, [pdfLink]);
  return (
    <>
      {isLoading && <Loader />}
      <div
        className="modal custom-slide-modal"
        tabIndex={-1}
        id="firstModal"
        data-bs-backdrop="static"
        data-bs-keyboard="false"
        aria-labelledby="staticBackdropLabel"
        aria-hidden="true"
      >
        <div className="modal-dialog">
          <div className="modal-content">
            <div className="modal-header">
              <h5 className="modal-title">Cited Cases</h5>
              <button
                type="button"
                className="btn-close"
                data-bs-dismiss="modal"
                aria-label="Close"
                onClick={() => {
                  resetAllData();
                }}
              ></button>
            </div>
            <div className="modal-body d-flex p-0">
              <div className="modal-left-element p-3">
                <div className="accordion" id="caseAccordion">
                  {modalData
                    ?.filter((result_detail) => result_detail?.is_cited)
                    ?.map((result_detail, index: number) => {
                      const caseData = result_detail.details;
                      return (
                        <div className="accordion-item" key={caseData?.case_id}>
                          <h2
                            className="accordion-header"
                            id={`heading${index}`}
                          >
                            <button
                              className="accordion-button collapsed"
                              type="button"
                              data-bs-toggle="collapse"
                              data-bs-target={`#collapse${index}`}
                              aria-expanded={false}
                              aria-controls={`collapse${index}`}
                            >
                              <strong className="fw-bold">
                                {caseData?.judgment_analysis.caseTitle} {" - "}
                                {caseData?.case_number} <br />
                              </strong>
                              <div className="row my-1">
                                <div
                                  className="col-12 col-sm-6"
                                  style={{ fontSize: 12 }}
                                >
                                  {caseData?.judgment_analysis.courtName}
                                </div>
                                <div
                                  className="col-12 col-sm-6 text-end"
                                  style={{ fontSize: 12 }}
                                >
                                  {caseData?.judgment_analysis.dateOfJudgment}
                                </div>
                              </div>
                            </button>
                          </h2>
                          <div
                            id={`collapse${index}`}
                            className={`accordion-collapse collapse`}
                            aria-labelledby={`heading${index}`}
                            data-bs-parent="#caseAccordion"
                          >
                            <div className="accordion-body">
                              {/* <p>
                                <strong className="fw-bold">Date of Judgment:</strong>{" "}
                                {caseData?.judgment_analysis.dateOfJudgment}
                              </p>
                              <p>
                                <strong className="fw-bold">Court:</strong>{" "}
                                {caseData?.judgment_analysis.courtName}
                              </p> */}
                              {caseData?.judgment_analysis.keyFacts?.length ? (
                                <>
                                  <strong className="fw-bold">
                                    Key Facts:
                                  </strong>
                                  <br />
                                  <ul>
                                    {caseData?.judgment_analysis.keyFacts.map(
                                      (fact, i) => (
                                        <li key={i}>{fact}</li>
                                      )
                                    )}
                                  </ul>
                                </>
                              ) : null}
                              {caseData?.judgment_analysis.outcome && (
                                <p>
                                  <strong className="fw-bold">Outcome:</strong>
                                  <br />
                                  {caseData?.judgment_analysis.outcome}
                                </p>
                              )}
                              {caseData?.judgment_analysis.mainPrinciple && (
                                <p>
                                  <strong className="fw-bold">
                                    Main Principle:
                                  </strong>
                                  <br />
                                  {caseData?.judgment_analysis.mainPrinciple}
                                </p>
                              )}
                              {caseData?.judgment_analysis.factsBackground && (
                                <p>
                                  <strong className="fw-bold">
                                    Background:
                                  </strong>
                                  <br />
                                  {caseData?.judgment_analysis.factsBackground}
                                </p>
                              )}
                              {caseData?.judgment_analysis?.courtReasoning
                                ?.length ? (
                                <>
                                  <strong className="fw-bold">
                                    Court Reasoning:
                                  </strong>
                                  <br />
                                  <ul>
                                    {caseData?.judgment_analysis?.courtReasoning?.map(
                                      (reason, i) => (
                                        <li key={i}>{reason}</li>
                                      )
                                    )}
                                  </ul>
                                </>
                              ) : null}
                              {caseData?.judgment_analysis?.petitionerBasis
                                ?.length ? (
                                <>
                                  <strong className="fw-bold">
                                    Petitioner Basis:
                                  </strong>{" "}
                                  <br />
                                  <ul>
                                    {caseData?.judgment_analysis?.petitionerBasis?.map(
                                      (reason, i) => (
                                        <li key={i}>{reason}</li>
                                      )
                                    )}
                                  </ul>
                                </>
                              ) : null}
                              {caseData?.judgment_analysis?.petitionerPoints
                                ?.length ? (
                                <>
                                  <strong className="fw-bold">
                                    Petitioner Points:
                                  </strong>
                                  <br />
                                  <ul>
                                    {caseData?.judgment_analysis?.petitionerPoints?.map(
                                      (reason, i) => (
                                        <li key={i}>{reason}</li>
                                      )
                                    )}
                                  </ul>
                                </>
                              ) : null}
                              {caseData?.judgment_analysis?.respondentBasis
                                ?.length ? (
                                <>
                                  <strong className="fw-bold">
                                    Respondent Basis:
                                  </strong>
                                  <br />
                                  <ul>
                                    {caseData?.judgment_analysis?.respondentBasis?.map(
                                      (reason, i) => (
                                        <li key={i}>{reason}</li>
                                      )
                                    )}
                                  </ul>
                                </>
                              ) : null}
                              {caseData?.judgment_analysis?.respondentPoints
                                ?.length ? (
                                <>
                                  <strong className="fw-bold">
                                    Respondent Points:
                                  </strong>
                                  <br />
                                  <ul>
                                    {caseData?.judgment_analysis?.respondentPoints?.map(
                                      (reason, i) => (
                                        <li key={i}>{reason}</li>
                                      )
                                    )}
                                  </ul>
                                </>
                              ) : null}
                              {fileId !== caseData?.case_number ? (
                                <button
                                  type="button"
                                  className="btn btn-primary"
                                  onClick={() => {
                                    setFileId(caseData?.case_number);
                                    EnableRightElement();
                                  }}
                                >
                                  View Judgement
                                </button>
                              ) : null}
                              {pdfLink && fileId === caseData?.case_number ? (
                                <button
                                  type="button"
                                  className="btn btn-outline-warning"
                                  onClick={() => {
                                    setFileId(undefined);
                                    setPdfLink("");
                                    DisableRightElement();
                                  }}
                                >
                                  Close Judgement File
                                </button>
                              ) : null}
                            </div>
                          </div>
                        </div>
                      );
                    })}
                </div>
                {modalData?.some((searchItem) => !searchItem.is_cited) && (
                  <h3 className="fs-6 mt-4 mb-3">Other Related Cases</h3>
                )}
                <div className="accordion" id="caseAccordion1">
                  {modalData
                    ?.filter((result_detail) => !result_detail?.is_cited)
                    ?.map((result_detail, otherIndex) => {
                      const caseData = result_detail.details;
                      return (
                        <div className="accordion-item" key={caseData?.case_id}>
                          <h2
                            className="accordion-header"
                            id={`other-heading${otherIndex}`}
                          >
                            <button
                              className="accordion-button collapsed"
                              type="button"
                              data-bs-toggle="collapse"
                              data-bs-target={`#other-collapse${otherIndex}`}
                              aria-expanded={false}
                              aria-controls={`other-collapse${otherIndex}`}
                            >
                              <strong className="fw-bold">
                                {caseData?.judgment_analysis.caseTitle} {"-"} (
                                {caseData?.case_number}) <br />
                              </strong>
                              <div className="row my-1">
                                <div
                                  className="col-12 col-sm-6"
                                  style={{ fontSize: 12 }}
                                >
                                  {caseData?.judgment_analysis.courtName}
                                </div>
                                <div
                                  className="col-12 col-sm-6  text-end"
                                  style={{ fontSize: 12 }}
                                >
                                  {caseData?.judgment_analysis.dateOfJudgment}
                                </div>
                              </div>
                            </button>
                          </h2>
                          <div
                            id={`other-collapse${otherIndex}`}
                            className={`accordion-collapse collapse`}
                            aria-labelledby={`other-heading${otherIndex}`}
                            data-bs-parent="#caseAccordion1"
                          >
                            <div className="accordion-body">
                              {/* <p>
                                <strong className="fw-bold">Date of Judgment:</strong>{" "}
                                {caseData?.judgment_analysis.dateOfJudgment}
                              </p>
                              <p>
                                <strong className="fw-bold">Court:</strong>{" "}
                                {caseData?.judgment_analysis.courtName}
                              </p> */}
                              {caseData?.judgment_analysis.keyFacts?.length ? (
                                <>
                                  <strong className="fw-bold">
                                    Key Facts:
                                  </strong>
                                  <br />
                                  <ul>
                                    {caseData?.judgment_analysis.keyFacts.map(
                                      (fact, i) => (
                                        <li key={i}>{fact}</li>
                                      )
                                    )}
                                  </ul>
                                </>
                              ) : null}
                              {caseData?.judgment_analysis.outcome ? (
                                <p>
                                  <strong className="fw-bold">Outcome:</strong>
                                  <br />
                                  {caseData?.judgment_analysis.outcome}
                                </p>
                              ) : null}
                              {caseData?.judgment_analysis.mainPrinciple ? (
                                <p>
                                  <strong className="fw-bold">
                                    Main Principle:
                                  </strong>
                                  <br />
                                  {caseData?.judgment_analysis.mainPrinciple}
                                </p>
                              ) : null}
                              {caseData?.judgment_analysis.factsBackground ? (
                                <p>
                                  <strong className="fw-bold">
                                    Background:
                                  </strong>{" "}
                                  {caseData?.judgment_analysis.factsBackground}
                                </p>
                              ) : null}
                              {caseData?.judgment_analysis?.courtReasoning
                                ?.length ? (
                                <>
                                  <strong className="fw-bold">
                                    Court Reasoning:
                                  </strong>
                                  <br />
                                  <ul>
                                    {caseData?.judgment_analysis?.courtReasoning?.map(
                                      (reason, i) => (
                                        <li key={i}>{reason}</li>
                                      )
                                    )}
                                  </ul>
                                </>
                              ) : null}
                              {caseData?.judgment_analysis?.petitionerBasis
                                ?.length ? (
                                <>
                                  <strong className="fw-bold">
                                    Petitioner Basis:
                                  </strong>{" "}
                                  <br />
                                  <ul>
                                    {caseData?.judgment_analysis?.petitionerBasis?.map(
                                      (reason, i) => (
                                        <li key={i}>{reason}</li>
                                      )
                                    )}
                                  </ul>
                                </>
                              ) : null}
                              {caseData?.judgment_analysis?.petitionerPoints
                                ?.length ? (
                                <>
                                  <strong className="fw-bold">
                                    Petitioner Points:
                                  </strong>{" "}
                                  <br />
                                  <ul>
                                    {caseData?.judgment_analysis?.petitionerPoints?.map(
                                      (reason, i) => (
                                        <li key={i}>{reason}</li>
                                      )
                                    )}
                                  </ul>
                                </>
                              ) : null}
                              {caseData?.judgment_analysis?.respondentBasis
                                ?.length ? (
                                <>
                                  <strong className="fw-bold">
                                    Respondent Basis:
                                  </strong>
                                  <br />
                                  <ul>
                                    {caseData?.judgment_analysis?.respondentBasis?.map(
                                      (reason, i) => (
                                        <li key={i}>{reason}</li>
                                      )
                                    )}
                                  </ul>
                                </>
                              ) : null}
                              {caseData?.judgment_analysis?.respondentPoints
                                ?.length ? (
                                <>
                                  <strong className="fw-bold">
                                    Respondent Points:
                                  </strong>
                                  <br />
                                  <ul>
                                    {caseData?.judgment_analysis?.respondentPoints?.map(
                                      (reason, i) => (
                                        <li key={i}>{reason}</li>
                                      )
                                    )}
                                  </ul>
                                </>
                              ) : null}
                              {fileId !== caseData?.case_number ? (
                                <button
                                  type="button"
                                  className="btn btn-primary"
                                  onClick={() => {
                                    setFileId(caseData?.case_number);
                                    EnableRightElement();
                                  }}
                                >
                                  View Judgement
                                </button>
                              ) : null}
                              {pdfLink && fileId === caseData?.case_number ? (
                                <button
                                  type="button"
                                  className="btn btn-outline-warning"
                                  onClick={() => {
                                    setFileId(undefined);
                                    setPdfLink("");
                                    DisableRightElement();
                                  }}
                                >
                                  Close Judgement File
                                </button>
                              ) : null}
                            </div>
                          </div>
                        </div>
                      );
                    })}
                </div>
              </div>
              <div className="modal-right-element d-none">
                {pdfLink && (
                  <>
                    <button
                      className="bg-white text-dark rounded-5 d-inline-block d-md-none"
                      onClick={() => {
                        DisableRightElement();
                        setFileId(undefined);
                        setPdfLink("");
                      }}
                    >
                      Close
                    </button>
                    <iframe src={`${pdfLink}`}></iframe>
                  </>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>
      <div
        className="modal feedback-modal modal-lg"
        tabIndex={-1}
        id="feedbackModal"
        data-bs-backdrop="static"
        data-bs-keyboard="false"
        aria-labelledby="staticBackdropLabel"
        aria-hidden="true"
      >
        <div className="modal-dialog">
          <div className="modal-content">
            <div className="modal-header">
              <h5 className="modal-title">Suggest Improvements</h5>
            </div>
            <div className="modal-body">
              <p className="text-dark">
                What was the issue with the response? How could it be improved?
              </p>
              <div
                className="row"
                role="group"
                aria-label="Basic checkbox toggle button group"
              >
                {checkBoxOptions?.map(
                  (checkBoxOption: string, index: number) => {
                    return (
                      <div
                        className="col-sm-12 col-md-6 mb-3"
                        key={checkBoxOption}
                      >
                        <div className="form-group">
                          <input
                            type="checkbox"
                            className="me-3"
                            id={`checkBoxOption-${index}`}
                            autoComplete="off"
                            checked={feedbackSuggestion?.includes(
                              checkBoxOption
                            )}
                            onChange={() =>
                              handleCheckboxChange(checkBoxOption)
                            }
                          />
                          <label
                            className=""
                            htmlFor={`checkBoxOption-${index}`}
                          >
                            {checkBoxOption}
                          </label>
                        </div>
                      </div>
                    );
                  }
                )}
                <div className="col-sm-12 col-md-12 mb-3">
                  <div className="form-group">
                    <label htmlFor="desc" className="mb-2">
                      <strong className="fw-bold">Describe</strong> (Optional)
                    </label>
                    <textarea
                      name=""
                      className="form-control"
                      id="desc"
                      placeholder="Describe your suggestion"
                      value={suggestionMsg}
                      onChange={(e) => {
                        setSuggestionMsg(e?.target?.value);
                      }}
                    ></textarea>
                  </div>
                </div>
              </div>
            </div>
            <div className="modal-footer">
              <button
                type="button"
                className="btn btn-secondary"
                data-bs-dismiss="modal"
                onClick={clearPayload}
              >
                Close
              </button>
              <button
                type="button"
                className="btn btn-primary text-white fw-bold"
                disabled={!feedbackSuggestion?.length}
                onClick={submitFeedback}
                data-bs-dismiss="modal"
              >
                Save changes
              </button>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
