export const QUERY_SUGGESTIONS = [
  "Is death penalty constitutional in India?",
  "Alimony Laws in Divorce?",
  "What are the legal rights and status of LGBTQ individuals in India?",
  "What is the standard structure of directors and their liabilities in India?",
];
